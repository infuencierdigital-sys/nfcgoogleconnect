import { index, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

// Every app entity (Cliente, Lead, Pedido, …) is stored as a JSON document in one
// table, mirroring the document model the app was built on. `entity` names the
// collection; the fields live in `data`.
export const records = pgTable(
  "records",
  {
    id: text().primaryKey(),
    entity: text().notNull(),
    data: jsonb().notNull().default({}),
    createdDate: timestamp("created_date", { withTimezone: true }).notNull().defaultNow(),
    updatedDate: timestamp("updated_date", { withTimezone: true }).notNull().defaultNow(),
    createdBy: text("created_by"),
    createdById: text("created_by_id"),
  },
  (t) => [
    index("records_entity_created_idx").on(t.entity, t.createdDate),
    index("records_data_gin_idx").using("gin", t.data),
  ],
);
