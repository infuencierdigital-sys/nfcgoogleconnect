// Plain config object (no import from "drizzle-kit") so the config loads even
// when drizzle-kit is executed via npx without local node_modules.
export default {
  dialect: "postgresql",
  schema: "./db/schema.ts",
  out: "netlify/database/migrations",
};
