import { handleAuthCallback } from "@netlify/identity";
import { useEffect } from "react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { INVITE_TOKEN_KEY } from "@/components/auth/ResetPasswordPage";
import { sanitizeReturnTo } from "@/lib/authReturnTo";

const CALLBACK_HASH = /(confirmation_token|recovery_token|invite_token|email_change_token|access_token|error)=/;

/**
 * Handles the links Netlify Identity sends (e-mail confirmation, password
 * recovery, invitations, Google sign-in). They land on the site with a token in
 * the URL hash; this processes it once on page load.
 */
export function AuthCallback() {
  useEffect(() => {
    if (!CALLBACK_HASH.test(window.location.hash)) return;
    handleAuthCallback()
      .then((result) => {
        if (!result) return;
        if (result.type === "recovery") {
          window.location.href = "/reset-password";
        } else if (result.type === "invite" && result.token) {
          sessionStorage.setItem(INVITE_TOKEN_KEY, result.token);
          window.location.href = "/reset-password";
        } else if (result.type === "oauth" || result.type === "confirmation") {
          base44.auth.homeAfterLogin(sanitizeReturnTo(base44.auth.takeStoredReturnTo() || "/")).then((to) => (window.location.href = to));
        } else if (result.type === "email_change") {
          toast.success("E-mail atualizado.");
        }
      })
      .catch((err) => toast.error(err?.message || "Este link expirou ou já foi usado."));
  }, []);
  return null;
}
