import { Link } from "@tanstack/react-router";
import { acceptInvite, getUser } from "@netlify/identity";
import { AlertTriangle, Lock } from "lucide-react";
import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { AuthLayout } from "@/components/auth/AuthLayout";
import { authErrorMessage } from "@/components/auth/errors";
import { AuthError, SubmitButton } from "@/components/auth/parts";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

// The /reset-password page. Reached from the e-mail links Netlify Identity sends:
// a recovery link signs the visitor in first (see AuthCallback), an invitation
// link brings its token along in sessionStorage so the visitor can pick a password.
export const INVITE_TOKEN_KEY = "auth:inviteToken";

export function ResetPasswordPage() {
  const [inviteToken] = useState(() => sessionStorage.getItem(INVITE_TOKEN_KEY));
  const [signedIn, setSignedIn] = useState(null);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (inviteToken) return;
    getUser()
      .then((u) => setSignedIn(!!u))
      .catch(() => setSignedIn(false));
  }, [inviteToken]);

  async function submit(e) {
    e.preventDefault();
    setError("");
    if (password !== confirm) {
      setError("As senhas não conferem.");
      return;
    }
    setBusy(true);
    try {
      if (inviteToken) {
        await acceptInvite(inviteToken, password);
        sessionStorage.removeItem(INVITE_TOKEN_KEY);
      } else {
        await base44.auth.setNewPassword(password);
      }
      window.location.href = await base44.auth.homeAfterLogin("/");
    } catch (err) {
      setError(authErrorMessage(err, "Não foi possível salvar a nova senha."));
      setBusy(false);
    }
  }

  if (!inviteToken && signedIn === null) return null;

  if (!inviteToken && !signedIn) {
    return (
      <AuthLayout
        icon={AlertTriangle}
        title="Link inválido"
        subtitle="Este link de redefinição expirou ou está incompleto"
        footer={
          <Link to="/forgot-password" className="font-medium text-primary hover:underline">
            Solicitar um novo link
          </Link>
        }
      >
        <p className="text-center text-sm text-foreground">Peça um novo e-mail de redefinição de senha e abra o link mais recente.</p>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout icon={Lock} title={inviteToken ? "Ative sua conta" : "Nova senha"} subtitle={inviteToken ? "Escolha uma senha para acessar" : "Digite sua nova senha"}>
      <AuthError>{error}</AuthError>
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="reset-password">Nova senha</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input id="reset-password" type="password" autoComplete="new-password" minLength={6} autoFocus placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} className="h-12 pl-10" required />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="reset-confirm">Confirmar senha</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input id="reset-confirm" type="password" autoComplete="new-password" minLength={6} placeholder="••••••••" value={confirm} onChange={(e) => setConfirm(e.target.value)} className="h-12 pl-10" required />
          </div>
        </div>
        <SubmitButton busy={busy} busyLabel="Salvando...">
          Salvar senha
        </SubmitButton>
      </form>
    </AuthLayout>
  );
}
