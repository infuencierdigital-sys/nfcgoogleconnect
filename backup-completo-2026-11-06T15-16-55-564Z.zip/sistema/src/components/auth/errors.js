import { AuthError, MissingIdentityError } from "@netlify/identity";

/** A Portuguese message for a Netlify Identity error. */
export function authErrorMessage(error, fallback = "Não foi possível concluir. Tente novamente.") {
  if (error instanceof MissingIdentityError) return "O login não está disponível neste ambiente.";
  if (error instanceof AuthError) {
    if (/not confirmed/i.test(error.message || "")) return "Confirme seu e-mail antes de entrar. Verifique sua caixa de entrada (e o spam).";
    if (/no user found|password invalid|invalid_grant/i.test(error.message || "")) return "E-mail ou senha inválidos.";
    if (error.status === 401) return "E-mail ou senha inválidos.";
    if (error.status === 403) return "Cadastros estão fechados. Peça um convite à equipe.";
    if (error.status === 422) return "Verifique o e-mail e a senha (mínimo de 6 caracteres).";
    return error.message || fallback;
  }
  return error?.message || fallback;
}
