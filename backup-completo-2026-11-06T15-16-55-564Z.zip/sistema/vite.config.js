import { fileURLToPath } from "node:url";
import netlify from "@netlify/vite-plugin-tanstack-start";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import codigoFonte from "./vite-plugin-codigo-fonte.js";

export default defineConfig({
  resolve: {
    alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) },
  },
  plugins: [codigoFonte(), tanstackStart({ srcDirectory: "src" }), react(), netlify()],
});
